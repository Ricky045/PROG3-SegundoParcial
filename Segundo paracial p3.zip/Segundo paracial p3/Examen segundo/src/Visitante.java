import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Visitante {

    private final StringProperty nombre;
    private final StringProperty tipo;

    public Visitante(String nombre, String tipo) {
        this.nombre = new SimpleStringProperty(nombre);
        this.tipo = new SimpleStringProperty(tipo);
    }

    public StringProperty nombreProperty() {
        return nombre;
    }

    public StringProperty tipoProperty() {
        return tipo;
    }
}