import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class RegistroVisitantesApp extends Application {

    private TableView<Visitante> tabla;
    private ObservableList<Visitante> listaVisitantes;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {

        listaVisitantes = FXCollections.observableArrayList();

        Label titulo = new Label("Sistema de Registro de Visitantes");
        titulo.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        TextField txtNombre = new TextField();
        txtNombre.setPromptText("Ingrese el nombre del visitante...");

        ComboBox<String> cbTipo = new ComboBox<>();
        cbTipo.getItems().addAll("Estudiante", "Docente", "Administrativo", "Invitado");
        cbTipo.setValue("Estudiante");

        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);

        form.add(new Label("Nombre completo:"), 0, 0);
        form.add(txtNombre, 0, 1);

        form.add(new Label("Tipo de visitante:"), 1, 0);
        form.add(cbTipo, 1, 1);

        Button btnAgregar = new Button("+ Agregar visitante");
        Button btnNuevoTipo = new Button("Nuevo tipo");
        Button btnEliminar = new Button("Eliminar visitante");
        Button btnLimpiar = new Button("Limpiar");
        Button btnGuardar = new Button("Guardar visitantes");

        HBox botones = new HBox(10, btnAgregar, btnNuevoTipo, btnEliminar, btnLimpiar, btnGuardar);

        tabla = new TableView<>();

        TableColumn<Visitante, String> colNombre = new TableColumn<>("Nombre");
        colNombre.setCellValueFactory(data -> data.getValue().nombreProperty());
        colNombre.setPrefWidth(300);

        TableColumn<Visitante, String> colTipo = new TableColumn<>("Tipo de visitante");
        colTipo.setCellValueFactory(data -> data.getValue().tipoProperty());
        colTipo.setPrefWidth(200);

        tabla.getColumns().addAll(colNombre, colTipo);
        tabla.setItems(listaVisitantes);

        Label lblTotal = new Label("Total de visitantes registrados: 0");

        btnAgregar.setOnAction(e -> {
            String nombre = txtNombre.getText();
            String tipo = cbTipo.getValue();

            if (!nombre.isEmpty()) {
                listaVisitantes.add(new Visitante(nombre, tipo));
                txtNombre.clear();
                actualizarTotal(lblTotal);
            }
        });

        btnEliminar.setOnAction(e -> {
            Visitante seleccionado = tabla.getSelectionModel().getSelectedItem();
            if (seleccionado != null) {
                listaVisitantes.remove(seleccionado);
                actualizarTotal(lblTotal);
            }
        });

        btnLimpiar.setOnAction(e -> {
            listaVisitantes.clear();
            actualizarTotal(lblTotal);
        });

        btnNuevoTipo.setOnAction(e -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Nuevo Tipo");
            dialog.setHeaderText("Agregar nuevo tipo de visitante");

            dialog.showAndWait().ifPresent(tipo -> cbTipo.getItems().add(tipo));
        });

        btnGuardar.setOnAction(e -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Guardar");
            alert.setHeaderText(null);
            alert.setContentText("Visitantes guardados correctamente.");
            alert.showAndWait();
        });

        VBox root = new VBox(15, titulo, form, botones, tabla, lblTotal);
        root.setPadding(new Insets(15));

        Scene scene = new Scene(root, 600, 500);

        stage.setTitle("Registro de Visitantes");
        stage.setScene(scene);
        stage.show();
    }

    private void actualizarTotal(Label label) {
        label.setText("Total de visitantes registrados: " + listaVisitantes.size());
    }
}  